
package spaceinvaders;

public class AlienFactory {

    private Alien prototype;

    public AlienFactory(Alien prototype) {
        this.prototype = prototype;
    }

    public Alien createAlien(int x, int y) {
        Alien clone = prototype.clone();
        clone.setX(x);
        clone.setY(y);
        return clone;
    }
}

package spaceinvaders;

public class BombFactory {

    private static Bomb prototype = PushPanel.createBomb(0, 0);//edit

    public static void setPrototype(Bomb p) {
        prototype = p;
    }

    public static Bomb createBomb(int x, int y) {
        Bomb clone = prototype.clone();
        clone.setX(x);
        clone.setY(y);
        clone.setDestroyed(false);
        return clone;
    }
}

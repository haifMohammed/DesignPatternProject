package spaceinvaders;

import javax.swing.ImageIcon;

/**
 * 
 * @author
 */
public class GameOver extends Sprite implements Commons {

	private int width;

	/*
	 * Constructor
	 */
	public GameOver() {
        setImage(PushPanel.getSharedImage("/img/gameover.png"));//edit

		
		setX(0);
		setY(0);
	}

	/*
	 * Getters & Setters
	 */

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}
}

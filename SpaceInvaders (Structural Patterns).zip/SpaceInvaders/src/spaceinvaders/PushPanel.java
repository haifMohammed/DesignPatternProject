package spaceinvaders;

import java.awt.*;
import java.awt.Image;
import java.awt.event.*;
import java.util.HashMap;
import javax.swing.*;

/**
 *
 * @author
 */
public class PushPanel extends JPanel {


    private JButton push;

    private static final HashMap<String, Image> sharedImages = new HashMap<>();

    public static Image getSharedImage(String path) {
        return sharedImages.computeIfAbsent(path, p -> {
            ImageIcon icon = new ImageIcon(PushPanel.class.getResource(p));
            return icon.getImage();
        });
    }

    public static Player createPlayer() {
        return new Player();
    }

    public static Alien createAlien(int x, int y) {
        return new Alien(x, y);
    }

    public static Bomb createBomb(int x, int y) {
        return BombFactory.createBomb(x, y);
    }


    public static void startGame() {
        JFrame frame = new JFrame("Space Invaders");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(Commons.BOARD_WIDTH, Commons.BOARD_HEIGTH);
        frame.getContentPane().add(new Board());
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public static void showIntroScreen() {
        JFrame introFrame = new JFrame("Space Invaders");

        String topMessage = "<html><br><br>Space Invaders<br>Java Version</html>";
        String introMessage = "<html>Ajude-nos, capitão impressionante!!<br>" +
                "Os alienígenas estão tentando invadir nosso planeta.<br><br>" +
                "Sua missão:<br><br>Matar todos os alienígenas invasores antes que eles consigam invadir o planeta Terra.<br>" +
                "E, de preferência, não morra durante a batalha!<br><br><br>BOA SORTE!!!</html>";

        JLabel topLabel = new JLabel(topMessage, SwingConstants.CENTER);
        JLabel introLabel = new JLabel(introMessage, SwingConstants.CENTER);
        topLabel.setFont(new Font("Helvetica", Font.BOLD, 20));
        introLabel.setFont(new Font("Helvetica", Font.BOLD, 12));

        JButton startButton = new JButton("Iniciar Missão");
        JButton helpButton = new JButton("Ajuda");

        startButton.addActionListener(e -> {
            introFrame.dispose();
            startGame();
        });

        helpButton.addActionListener(e -> showHelpScreen());

        JPanel bottomPanel = new JPanel();
        bottomPanel.add(helpButton);
        bottomPanel.add(startButton);

        introFrame.add(topLabel, BorderLayout.PAGE_START);
        introFrame.add(introLabel, BorderLayout.CENTER);
        introFrame.add(bottomPanel, BorderLayout.PAGE_END);
        introFrame.setSize(500, 500);
        introFrame.setLocationRelativeTo(null);
        introFrame.setResizable(false);
        introFrame.setVisible(true);
    }
    public static void showHelpScreen() {
        JFrame helpFrame = new JFrame("Ajuda");

        String helpTop = "<html><br>Ajuda</html>";
        String helpMessage = "<html>Controles:<br><br>" +
                "Movimento Esquerda: Seta Esquerda<br>" +
                "Movimento Direita: Seta Direita<br>" +
                "Atirar: Barra de espaço</html>";

        JLabel topLabel = new JLabel(helpTop, SwingConstants.CENTER);
        JLabel helpLabel = new JLabel(helpMessage, SwingConstants.CENTER);
        topLabel.setFont(new Font("Helvetica", Font.BOLD, 20));
        helpLabel.setFont(new Font("Helvetica", Font.BOLD, 12));

        JButton closeButton = new JButton("Fechar");
        closeButton.addActionListener(e -> helpFrame.dispose());

        helpFrame.add(topLabel, BorderLayout.PAGE_START);
        helpFrame.add(helpLabel, BorderLayout.CENTER);
        helpFrame.add(closeButton, BorderLayout.PAGE_END);
        helpFrame.setSize(300, 300);
        helpFrame.setLocationRelativeTo(null);
        helpFrame.setResizable(false);
        helpFrame.setVisible(true);
    }
}



   
package spaceinvaders;

public class SpaceInvaders {

    public static void main(String[] args) {
        PushPanel.showIntroScreen();
    }

}
